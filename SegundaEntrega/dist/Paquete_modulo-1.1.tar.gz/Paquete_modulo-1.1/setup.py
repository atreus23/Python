from setuptools import setup 

setup(
    name="Paquete_modulo",
    version="1.1",
    description="Primer paquete",
    author="Luis Tecchio",
    author_email="tecchio2014@gmail.com",
    packages=['Modulo']
)